<?php
require '../connection.php';

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];

$stmt = $conn->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
$stmt->bindParam(1, $username);
$stmt->bindParam(3, $email);
$stmt->bindParam(2, $password);

if ($stmt->execute()) {

    header("Location: ../Login/login.html");
    exit();
} else {

    echo "Registration failed!";
}

$conn = null;
?>
