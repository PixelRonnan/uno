<?php

function connectToDatabase()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "yumis";


    $conn = new mysqli($servername, $username, $password, $dbname);


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}


function validateCredentials($username, $password)
{

    $conn = connectToDatabase();
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {

        return true;
    } else {

        return false;
    }
}

// Function to handle login form submission
function handleLogin()
{
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];

        if (validateCredentials($username, $password)) {
            header("Location: product_page.php");
            exit();
        } else {
            echo "Invalid credentials. Please try again.";
        }
    }
}
handleLogin();
?>
