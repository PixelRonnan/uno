<?php
session_start(); 
require '../connection.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);   

// Retrieve form data
$username = $_POST['username'];
$password = $_POST['password'];


$stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
$stmt->bindParam(':username', $username);
$stmt->execute();


if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $hashedPassword = $row['password'];

    if (password_verify($password, $hashedPassword)) {
        $_SESSION['username'] = $username; 
        header("Location: ../index/index.html");
        exit();
    } 
} else {
 
    echo "User not found!";
}


$conn = null;
?>
