<?php
session_start();

$host = 'localhost';
$db_name = 'yumis';
$db_user = 'root';
$db_pass = '';

try {
    $pdo = new PDO("mysql:host={$host};dbname={$db_name}", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

function getProductsFromDatabase()
{
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM products");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$products = getProductsFromDatabase();


$productsPerPage = 3;

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

function addToCart($product_id, $quantity) {
    $index = array_search($product_id, array_column($_SESSION['cart'], 'product_id'));

    if ($index !== false) {

        $_SESSION['cart'][$index]['quantity'] += $quantity;
    } else {

        $_SESSION['cart'][] = array(
            'product_id' => $product_id,
            'quantity' => $quantity
        );
    }
}

function removeFromCart($product_id) {
    $index = array_search($product_id, array_column($_SESSION['cart'], 'product_id'));
    if ($index !== false) {
        unset($_SESSION['cart'][$index]);
    }
}

function clearCart() {
    $_SESSION['cart'] = array();
}

function filterProducts($query) {
    global $products;
    $filteredProducts = array();
    foreach ($products as $product) {
        if (stripos($product['name'], $query) !== false) {
            $filteredProducts[] = $product;
        }
    }
    return $filteredProducts;
}

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchQuery = $_GET['search'];
    $products = filterProducts($searchQuery);
}

function getTotalPages($totalProducts, $productsPerPage) {
    return ceil($totalProducts / $productsPerPage);
}

function getCurrentPage() {
    return isset($_GET['page']) ? intval($_GET['page']) : 1;
}

$totalProducts = count($products);
$currentPage = getCurrentPage();
$totalPages = getTotalPages($totalProducts, $productsPerPage);

$startIndex = ($currentPage - 1) * $productsPerPage;

$productsOnPage = array_slice($products, $startIndex, $productsPerPage);

function updateCartItemQuantity($product_id, $quantity) {
    $index = array_search($product_id, array_column($_SESSION['cart'], 'product_id'));
    if ($index !== false) {
        $_SESSION['cart'][$index]['quantity'] = $quantity;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_to_cart'])) {
        addToCart($_POST['product_id'], $_POST['quantity']);
    } elseif (isset($_POST['remove_from_cart'])) {
        removeFromCart($_POST['product_id']);
    } elseif (isset($_POST['update_quantity'])) {
        updateCartItemQuantity($_POST['product_id'], $_POST['quantity']);
    } elseif (isset($_POST['clear_cart'])) {
        clearCart();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Product Page</h1>
        <form method="get" class="search-form">
            <input type="text" name="search" placeholder="Search products..." value="<?php echo isset($searchQuery) ? htmlspecialchars($searchQuery) : ''; ?>">
            <button type="submit">Search</button>
        </form>
        <div class="product-container">
            <?php if (empty($productsOnPage)): ?>
                <p>No products found for the search query.</p>
            <?php else: ?>
                <?php foreach ($productsOnPage as $product): ?>
                    <div class="product">
                        <?php if (isset($product['image']) && !empty($product['image'])): ?>
                            <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="product-image">
                        <?php endif; ?>
                        <h2><?php echo $product['name']; ?></h2>
                        <p>Price: $<?php echo $product['price']; ?></p>
                        <form method="post">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <input type="number" name="quantity" value="1" min="1" max="10">
                            <input type="submit" name="add_to_cart" value="Add to Cart">
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="pagination">
            <?php if ($totalPages > 1): ?>
                <?php for ($page = 1; $page <= $totalPages; $page++): ?>
                    <?php if ($page === $currentPage): ?>
                        <span class="current-page"><?php echo $page; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $page; ?>"><?php echo $page; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
            <?php endif; ?>
        </div>
        <div class="cart-container">
            <h2>Cart</h2>
            <?php if (empty($_SESSION['cart'])): ?>
                <p>Your cart is empty.</p>
            <?php else: ?>
                <?php foreach ($_SESSION['cart'] as $cart_item): ?>
                    <?php $product = $products[$cart_item['product_id'] - 1]; ?>
                    <div class="cart-item">
                        <div class="cart-item-details">
                            <p><?php echo $product['name']; ?> - $<?php echo $product['price']; ?> x <?php echo $cart_item['quantity']; ?></p>
                            <form method="post">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <input type="number" name="quantity" value="<?php echo $cart_item['quantity']; ?>" min="1" max="10">
                                <input type="submit" name="update_quantity" value="Update">
                            </form>
                        </div>
                        <form method="post">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <input type="submit" name="remove_from_cart" value="Remove">
                        </form>
                    </div>
                <?php endforeach; ?>
                <p class="cart-total">Total: $<?php echo array_reduce($_SESSION['cart'], function ($total, $cart_item) use ($products) {
                    $product = $products[$cart_item['product_id'] - 1];
                    return $total + ($product['price'] * $cart_item['quantity']);
                }, 0); ?></p>
                <div class="clear-cart">
                    <form method="post">
                        <input type="hidden" name="clear_cart" value="true">
                        <button type="submit">Clear Cart</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
